% Specify the number of nodes
J=3;  % there are J unique nodes
h=1/(J);
n_nodes=J+1; % there is a  bonus node that corresponds to the point zero.


% do some pre computations:
x=0:0.01:1;
y_line=zeros(size(x));
nodes_location=(0:J)*h;



%for mode_no=0:J+2
for mode_no=0:J-1

  figure;
  hold on

% Plot the unit line
  plot(x,y_line,'k','LineWidth',3);

% plot all nodes
  plot(nodes_location,zeros(size(nodes_location)),'.k','MarkerSize',50)

% plot discrete fourier cosine  mode
% plot continuous fourier cosine  mode

  plot(nodes_location,cos(2*pi*mode_no/J*(0:J)),'.','MarkerSize',50);
  plot((0:0.01:J)*h,cos(2*pi*mode_no/J*(0:0.01:J)),'LineWidth',3);

% plot discrete fourier sine  mode
% plot continuous fourier sine  mode

  plot(nodes_location,sin(2*pi*mode_no/J*(0:J)),'r.','MarkerSize',50);
  plot((0:0.01:J)*h,sin(2*pi*mode_no/J*(0:0.01:J)),'r','LineWidth',3);

title(['Standard numbering ', 'Mode ', num2str(mode_no), ', wavenumber ',num2str(2*pi*mode_no/(J))],'FontSize',16)
end
