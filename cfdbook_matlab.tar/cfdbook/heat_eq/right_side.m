function ye = right_side(t,x,mu,beta,u)
%RIGHT_SIDE
% Right-hand side for one-dimensional nonstationary convection-diffusion
% equation
xut = x - u*t*ones(size(x));
ye = mu*beta^2*cos(beta*xut);
