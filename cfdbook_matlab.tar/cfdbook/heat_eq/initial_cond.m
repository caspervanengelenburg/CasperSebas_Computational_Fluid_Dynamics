function ye = initial_cond(x)
n=length(x);
ye=zeros(size(x));
for i=1:n
	if (x(i) <0.4||x(i) >0.6)
		ye(i)=0;
	else
		ye(i)=1;
	end
end
return;