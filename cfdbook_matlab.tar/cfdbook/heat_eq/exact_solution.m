function ye = exact_solution(t,x,mu,alpha,beta,u)
%EXACT_SOLUTION
% Exact solution of nonstationary one-dimensional convection-diffusion equation.
xut = x - u*t*ones(size(x));
ye = cos(beta*xut) + exp(-mu*alpha*alpha*t)*cos(alpha*xut);
