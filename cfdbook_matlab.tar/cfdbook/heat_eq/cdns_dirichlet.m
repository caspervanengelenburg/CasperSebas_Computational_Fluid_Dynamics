%CDNS
% Numerical solution of nonstationary convection-diffusion equation: 
%	dv/dt + udv/dx - mu*d^2v/dx^2 = q,  
%	v(t,0)/dx = fL(t),  dv(t,1)/dx = fR(t)
%	q(t,x) = mu*beta^2*cos(beta(x-ut))
%	Exact solution: 
%	v = cos(beta(x-ut)) + exp(-alpha^2*mu*t)cos(alpha(x-ut))

% Copyright 2001 P. Wesseling
% This program and its subprograms may be freely used, modified and distributed
% under the GNU General Public License: http://www.gnu.org/copyleft/gpl.html

% Theory is given in Section 4.5 of
%	Computational Fluid Dynamics
%	Lecture Notes by P. Wesseling
%	Department of Applied Mathematical Analysis, ITS, TU Delft
% See http://ta.twi.tudelft.nl/nw/users/wesseling/

% This program generates Fig. 4.3 in the Lecture Notes

% Functions called: exact_solution, right_side,  fR

		% .......................Input..............................
mu = 0.1;	% Diffusion coefficient
J = 251;		% Number of cells is J-1
T = 0;		% Final time
T = 1.1;		% Final time
nu=0.5001;
tau =nu*(J-1)^(-2)/mu; 		% Time step
		% ....................End of input...........................

	% 	Vertex-centered uniform grid

	%                              
	%     x=0       J-1 cells     x=1
	%      |-------|-------|-------|
	%      1       2               J 

h = 1/(J-1);		% Mesh size
N = floor(T/tau);	% Number of time steps
x = linspace(0,1,J);	% Grid node locations: x_j = (j-1)/(J-1)
hh = h*ones(size(x')); 
hh(J,1) = h/2;		% Last cell has half size

	% Matrix generation
	% Coefficients in numerical flux are called beta:
	% F_{j+1/2} = beta0(j)v(j) + beta1(j+1)v(j+1), eq. (2.27)

e = ones(J,1); 
beta0 = nu*e;
B = spdiags([ beta0 e-2*beta0 beta0], -1:1, J, J);
B(1,2) = 2*nu;		%  boundary condition
B(J,J-1) = 2*nu;		%  boundary condition
%Dirichlet
B(1,1) = 1;
B(1,2) = 0;		%  boundary condition
B(J,J-1) = 0;		%  boundary condition
B(J,J)=1;
vo = initial_cond(x');	% Initial condition
vn = vo;					% Preallocation 

	% Time stepping 
tic
for n = 1:N
  vn=B*vo;vo=vn;
end
toc
		% Plot numerical solution at t = T
figure(1), clf, hold on
%plot(x,vn,'*','markersize',13)
plot(x,vn,'Linewidth',2)
axis([0 1 0 1.5]);
%  plot(x',exact_solution(t,x',mu,alpha,beta,u))
ha = findobj; set(ha(3),'FontSize',18)
title(['d=',num2str(nu,2),'   ',...
  num2str(J-1),' h  , T=',num2str(T,2)],...
  'fontsize',20)
title(['\nu=',num2str(nu,4),' h=', num2str(h),' \tau=',num2str(tau)],'fontsize',20)
box on
