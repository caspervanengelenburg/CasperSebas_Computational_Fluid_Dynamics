clear i; 
clf;
[X,Y] = meshgrid(-3:0.01:1,-4:0.01:4);
Mu = X+i*Y;
R = 1 + Mu + .5*Mu.^2 + (1/6)*Mu.^3 + (1/24)*Mu.^4;
%R = 1 + Mu +0.5*(Mu.*Mu);
Rhat=abs(R);
contour(X,Y,Rhat,[0.99999999],'LineWidth',2);
hold on;

% plot the rectangle
% a<=v<=0
% |w|<=b
a=1;
b=2.55;
plot([-a,0],[b b],'LineWidth',2);
plot([-a,0],[-b -b],'LineWidth',2);
plot([-a,-a],[-b b],'LineWidth',2);
plot([0,0],[-b b],'LineWidth',2);

% plot the ellipse
%(v/a)2+(w/b)^2=1;
t=pi/2:0.01:3/2*pi;
a=2.7853;
b=2.55;
plot([-3,1],[ 0 0 ]);
plot([ 0 0 ],[-4,4]);
axis([-3,1,-4,4]);
plot(a*cos(t),b*sin(t),'r','LineWidth',2);
title(['Stability Region for RK45'],'FontSize',16)
axis square
