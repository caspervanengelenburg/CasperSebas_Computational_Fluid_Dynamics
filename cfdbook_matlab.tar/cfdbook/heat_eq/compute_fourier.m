% computer Fourier expansion

% Specify the number of nodes
J=3;  % there are J unique nodes
h=1/(J);
n_nodes=J+1; % there is a  bonus node that corresponds to the point zero.

% define the grid function
  phi=[0,1,0.5,0];
%  phi=[0,1,2,3,4,4,4,2,1,0,5,6,7,3,2,4,5,1,2,0];

  %phi=[0,1,1,0];
% do some pre computations:

% Plot the unit line
%clf;
hold on;
x=0:0.01:1;
y_line=zeros(size(x));
nodes_location=(0:J)*h;

% Plot the unit line
clf;
hold on;
x=0:0.01:1;
y_line=zeros(size(x));
nodes_location=(0:J)*h;

if(mod(J,2)>0) %J is odd
	m=(J-1)/2;
	p=0;
else
	m=(J-2)/2;  %J is even
	p=1;
end

II=0;
for mode_no=-m:m+p
II=II+1;
% compute inner product of gridfunction with this mode
	c(II)=1/J*phi*exp(-2*i*pi*mode_no/(J)*(0:J)).';


end

phi_recon=zeros(size(nodes_location));
for II=0:J
for mode_no=-m:m+p
phi_recon(II+1)=phi_recon(II+1)+c(mode_no+m+1)*exp(2*i*pi*mode_no/(J)*II);
end
end

for mode_no=-m:m+p
  hold on

  plot(x,y_line,'k','LineWidth',1);
% plot all nodes
  plot(nodes_location,zeros(size(nodes_location)),'k.','MarkerSize',10)

  plot(nodes_location,real(c(mode_no+m+1)*exp(2*i*pi*mode_no/(J)*(0:J))),'.','MarkerSize',10);
    plot((0:0.01:J)*h,real(c(mode_no+m+1)*exp(2*i*pi*mode_no/(J)*(0:0.01:(J)))),'LineWidth',1);

  plot(nodes_location,imag(c(mode_no+m+1)*exp(2*i*pi*mode_no/(J)*(0:J))),'r.','MarkerSize',10);
   plot((0:0.01:J)*h,imag(c(mode_no+m+1)*exp(2*i*pi*mode_no/(J)*(0:0.01:(J)))),'r','LineWidth',1);
%   title(['Book numbering ', 'Mode ', num2str(mode_no), ', wavenumber ',num2str(2*pi*mode_no/(J))],'FontSize',16)
  plot(nodes_location,phi,'g.-','LineWidth',1,'MarkerSize',10);
  plot(nodes_location,phi_recon,'m.','MarkerSize',10);
end
