% Specify the number of nodes
J=3;  % there are J unique nodes
h=1/(J);
n_nodes=J; % there is a  bonus node that corresponds to the point zero.


% do some pre computations:

% Plot the unit line
x=0:0.01:1;
y_line=zeros(size(x));
nodes_location=(0:J)*h;

if(mod(J,2)>0) %J is odd
	m=(J-1)/2;
	p=0;
else
	m=(J-2)/2;  %J is even
	p=1;
end
%close all
%  for mode_no=-m:-m
for mode_no=-m:m+p
  figure;
  hold on

  plot(x,y_line,'k','LineWidth',3);
% plot all nodes
  plot(nodes_location,zeros(size(nodes_location)),'k.','MarkerSize',50)

  plot(nodes_location,cos(2*pi*mode_no/(J)*(0:J)),'.','MarkerSize',50);
    plot((0:0.01:J)*h,cos(2*pi*mode_no/(J)*(0:0.01:(J))),'LineWidth',3);

  plot(nodes_location,sin(2*pi*mode_no/(J)*(0:J)),'r.','MarkerSize',50);
   plot((0:0.01:J)*h,sin(2*pi*mode_no/(J)*(0:0.01:(J))),'r','LineWidth',3);
title(['Book numbering ', 'Mode ', num2str(mode_no), ', wavenumber ',num2str(2*pi*mode_no/(J))],'FontSize',16)
end

