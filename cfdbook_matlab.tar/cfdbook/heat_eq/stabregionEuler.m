clear i; 
clf;
[X,Y] = meshgrid(-2:0.01:0.1,-2:0.01:2);
Mu = X+i*Y;
R = 1 + Mu;
%R = 1 + Mu +0.5*(Mu.*Mu);
Rhat=abs(R);
contour(X,Y,Rhat,[0.99999999],'LineWidth',2);
hold on;


% plot the ellipse
%(v/a)2+(w/b)^2=1;
t=0:0.01:2*pi;
a=0.9;
b=0.9;
axis equal;
plot([-2.5,.5],[ 0 0 ]);
plot([ 0 0 ],[-1.5,1.5]);
axis([-3,.5,-1.5,1.5]);
plot(a*cos(t)-1,b*sin(t),'r','LineWidth',2);
axis equal
title(['Stability Region for Forward Euler'],'FontSize',16)
