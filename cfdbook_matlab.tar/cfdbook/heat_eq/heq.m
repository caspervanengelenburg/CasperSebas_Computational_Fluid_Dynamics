%HEQ
% Numerical solution of heat equation 
% with homogeneous Neumann boundary conditions:
%	dv/dt - mu*d^2v/dx^2 = 0,  dv(0)/dx = 0,   dv(1)/dx = 0

% Copyright 2001 P. Wesseling
% This program and its subprograms may be freely used, modified and distributed
% under the GNU General Public License: http://www.gnu.org/copyleft/gpl.html


% Theory is given in Section 4.2 of
%	Computational Fluid Dynamics
%	Lecture Notes by P. Wesseling
%	Department of Applied Mathematical Analysis, ITS, TU Delft
% See http://ta.twi.tudelft.nl/nw/users/wesseling/

% This program generates Fig. 4.1 in the Lecture Notes

% Functions called: none
clear;
		% .......................Input..............................
mu = 0.004;	% Diffusion coefficient
J = 20;		% Number of cells is J-1
T = 0.3;	% Final time
d = 0.2;	% Diffusion number = mu*tau/h^2
		% ....................End of input...........................

	% 	Vertex-centered uniform grid

	%                              
	%     x=0       J-1 cells     x=1
	%      |-------|-------|-------|
	%      1       2               J 

h = 1/(J-1);		% Mesh size
tau = d*h^2/mu;		% Time step
N = floor(T/tau);	% Number of time steps
x = linspace(0,1,J);	% Grid node locations: x_j = (j-1)/(J-1)
vo = zeros(J,1); vn = vo;	% Preallocation of old and new solution
 
x1 = 0.4; x2 = 0.6;	% Parameters for initial condition: vo = 1, x1 < x < x2

% Efficiency comparison of four implementations of the initial condition
	% First non-vectorized version:
tic
for j = 1:J
  if (x(j) > x1) & (x(j) < x2), vo(j) = 1; end 
end
toc
	% Second non-vectorized version:
tic
j1 = floor(1 + (J-1)*x1); j2 = ceil(1 + (J-1)*x2);
for j = j1:j2
  vo(j) = 1;
end
toc
	% First vectorized version:
tic	
j = floor(1 + (J-1)*x1):ceil(1 + (J-1)*x2);
vo(j) = 1;
toc
	% Second vectorized version:

tic	
vo(floor(1 + (J-1)*x1):ceil(1 + (J-1)*x2)) = 1;
toc

	% Matrix generation
e = ones(J,1);   de = d*e;
A = spdiags([de, e - 2*de, de], -1:1, J, J);
A(1,2) = 2*d;    A(J,J-1) = 2*d;

	% Time stepping with explicit Euler scheme
for n = 1:N
  vn = A*vo;  vo = vn;
end

		% Plot numerical solution at t = T
clf, figure(1), hold on, plot(x,vn)
h = findobj; set(h(3),'FontSize',18)
title(['d=',num2str(d),',  ',num2str(J-1),' cells,  T=',num2str(T),...
', \tau= ', num2str(tau),', h= ', num2str(1/(J-1))],'fontsize',20)
box on
