function ye = FR(t,mu,alpha,beta,u)
ye = - beta*sin(beta*(1-u*t)) - alpha*exp(-mu*alpha*alpha*t)*sin(alpha*(1-u*t));
