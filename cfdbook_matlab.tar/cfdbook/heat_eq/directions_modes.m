% illustrate the directions corresponding to the modes
% draw a unit circle:
J=500;  % there are J unique nodes
clf;

if(mod(J,2)>0) %J is odd
	m=(J-1)/2;
	p=0;
else
	m=(J-2)/2;  %J is even
	p=1;
end

t=0:0.01:2*pi;
plot(cos(t),sin(t));
hold on;
axis equal;
plot([-1.5,1.5],[ 0 0 ]);
plot([ 0 0 ],[-1.5,1.5]);
axis([-1.5,1.5,-1.5,1.5]);

theta=zeros(J,1);
for mode_no=-m:m+p
	theta(mode_no+m+1)=2*pi*mode_no/J;
end

X=[zeros(J,1),cos(theta)];
Y=[zeros(J,1),sin(theta)];

plot(X',Y','r','LineWidth',2)





