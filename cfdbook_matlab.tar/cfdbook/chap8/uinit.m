function y = uinit(x)
   y=0;
